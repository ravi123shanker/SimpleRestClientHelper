package com.ravidev.restclient;

/**
 * Created by ryadav3 on 12/7/2016.
 */

public class Error {
    private int code;
    private String error;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
